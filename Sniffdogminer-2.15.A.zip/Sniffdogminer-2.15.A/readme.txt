# SniffDog www.ahashpool.com

*This is Windows software designed for Nvidia 1080ti

Thanks to Arronsace and NemosMiner --SniffDog-- has been created to Monitor AHashPool.com mining pools in real-time in order to find the most profitable Algo /

Auto Benchmarks Each algo to get optimal speeds and benches throughout monitoring 

Fully automated / Set And Forget in Startsniff.bat/

How to set in StartSniff.bat:

1) Place your Bitcoin BTC address after -u in StartSniff.bat

2) Input your -Workername to StartSniff.bat (your Workername will also be used at ahashpool for identification of your rig)

4) Choose the algos you wish to mine and let SniffDog benchmark

5) Then go back into StartSniff.bat and select which algo you wish to mine and what interval (in seconds) you would like the auto switch set at

6) Go out with your friends and enjoy life! This is designed to catch market rise on coins when you're not there!

Auto Downloads Miners /   

Thank you to aaronsace for devoloping and maintaining "MultiPoolMiner" and Thank you nemosminer for maintaining "NemosMiner"

This is a free project feel free to donate be much appreciated. Arronance btc address: 1MsrCoAt8qM53HUMsUxvy9gMj3QVbHLazH

If you have Windows 7, please update PowerShell:
https://www.microsoft.com/en-us/download/details.aspx?id=50395

CCMiner may need 'MSVCR120.dll' if you don't already have it:
https://www.microsoft.com/en-us/download/details.aspx?id=40784
 
CCMiner may need 'VCRUNTIME140.DLL' if you don't already have it:
https://www.microsoft.com/en-us/download/details.aspx?id=48145

Running multiple cards its recommend to increase Virtual Memory 32gb-64gb is optimal
