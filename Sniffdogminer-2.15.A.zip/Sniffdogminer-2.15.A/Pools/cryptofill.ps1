﻿. .\Include.ps1

try
{
    $cryptofill_Request = Invoke-WebRequest "https://www.cryptofill.com/api/status" -UseBasicParsing | ConvertFrom-Json
}
catch
{
    return
}

if(-not $cryptofill_Request){return}

$Name = (Get-Item $script:MyInvocation.MyCommand.Path).BaseName

$Location = "US"

$cryptofill_Request | Get-Member -MemberType NoteProperty | Select -ExpandProperty Name | foreach {
    $cryptofill_Host = "$_.mine.cryptofill.com"
    $cryptofill_Port = $cryptofill_Request.$_.port
    $cryptofill_Algorithm = Get-Algorithm $cryptofill_Request.$_.name
    $cryptofill_Coin = "Unknown"

    $Divisor = 1000000
	
    switch($cryptofill_Algorithm)
    {
        "sha256"{$Divisor *= 1000000}
        "sha256t"{$Divisor *= 1000000}
        "blake"{$Divisor *= 1000}
        "blake2s"{$Divisor *= 1000}
	"blakecoin"{$Divisor *= 1000}
        "decred"{$Divisor *= 1000}
        "keccak"{$Divisor *= 1000}
        "keccakc"{$Divisor *= 1000}
	"lbry"{$Divisor *= 1000}
	"myr-gr"{$Divisor *= 1000}
	"quark"{$Divisor *= 1000}
        "qubit"{$Divisor *= 1000}
        "vanilla"{$Divisor *= 1000}
	"x11"{$Divisor *= 1000}
	"equihash"{$Divisor /= 1000}
        "yescrypt"{$Divisor /= 1000}
    }

    if((Get-Stat -Name "$($Name)_$($cryptofill_Algorithm)_Profit") -eq $null){$Stat = Set-Stat -Name "$($Name)_$($cryptofill_Algorithm)_Profit" -Value ([Double]$cryptofill_Request.$_.estimate_last24h/$Divisor)}
    else{$Stat = Set-Stat -Name "$($Name)_$($cryptofill_Algorithm)_Profit" -Value ([Double]$cryptofill_Request.$_.estimate_current/$Divisor)}
	
    if($Wallet)
    {
        [PSCustomObject]@{
            Algorithm = $cryptofill_Algorithm
            Info = $cryptofill_Coin
            Price = $Stat.Live
            StablePrice = $Stat.Week
            MarginOfError = $Stat.Fluctuation
            Protocol = "stratum+tcp"
            Host = $cryptofill_Host
            Port = $cryptofill_Port
            User = $Wallet
            Pass = "ID=$Workername,c=BTC"
            Location = $Location
            SSL = $false
        }
    }
}
